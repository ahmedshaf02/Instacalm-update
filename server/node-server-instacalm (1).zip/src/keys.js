
module.exports = {
    mongoUrl:"mongodb+srv://ahmedshaf:GaUjihNXNFamn3mi@cluster0-s3efd.mongodb.net/Database?retryWrites=true&w=majority",
    jsonKey:"fjwfnjn"
}