
*User Schema
*Post Schema

User and Post--
 	Signup Route http://localhost:4000/signup
	Signin Route http://localhost:4000/signin
	Home Route http://localhost:4000/
	Profile Route http://localhost:4000/profile
	Create Post Route http://localhost:4000/profile
	Profile Route for Other Users http://localhost:4000/profile/:id


